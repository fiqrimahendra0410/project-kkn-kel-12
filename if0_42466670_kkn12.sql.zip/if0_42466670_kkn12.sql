-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql206.infinityfree.com
-- Generation Time: Aug 16, 2026 at 01:41 PM
-- Server version: 11.4.12-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42466670_kkn12`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `id` int(11) NOT NULL,
  `kegiatan_id` int(11) NOT NULL,
  `anggota_id` int(11) NOT NULL,
  `status` enum('hadir','izin','sakit','alpha') NOT NULL DEFAULT 'alpha',
  `keterangan` varchar(255) DEFAULT NULL,
  `diperbarui_pada` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `akun_anggota`
--

CREATE TABLE `akun_anggota` (
  `id` int(11) NOT NULL,
  `anggota_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `harus_ganti_pw` tinyint(1) NOT NULL DEFAULT 1,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp(),
  `role` enum('admin','editor','viewer') DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `akun_anggota`
--

INSERT INTO `akun_anggota` (`id`, `anggota_id`, `username`, `password_hash`, `harus_ganti_pw`, `dibuat_pada`, `role`) VALUES
(1, 1, 'rizkitrisaputra', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(2, 2, 'anggierahmawati', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(3, 3, 'virahmanda', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(4, 4, 'muhammadfiqrimahendra', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(5, 5, 'adit', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(6, 6, 'nisa', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(7, 7, 'tiara', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(8, 8, 'aliya', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(9, 9, 'faturahman', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(10, 10, 'diah', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-12 23:46:31', 'admin'),
(11, 11, 'kania', '$2y$10$sy3WEQ08p9yjvfC7y8d.8Op7XRDqwdThTRtdJevHm3JddZjxdDUha', 0, '2026-07-21 16:12:11', 'viewer');

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `divisi_panitia_id` int(11) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `kelas` enum('reguler','pekerja') NOT NULL DEFAULT 'reguler',
  `urutan_carousel` int(11) NOT NULL DEFAULT 0,
  `nim` varchar(20) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp(),
  `kata_kata` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`id`, `nama`, `jabatan`, `divisi_panitia_id`, `foto`, `kelas`, `urutan_carousel`, `nim`, `no_hp`, `dibuat_pada`, `kata_kata`) VALUES
(1, 'Rizki Tri Saputra', 'Ketua KKN', 1, 'img/rizki tri saputra.jpg', 'reguler', 1, NULL, NULL, '2026-07-12 23:36:09', ''),
(2, 'Anggi Rahmawati', 'Sekretaris', 2, 'img/Anggi Rahmawati.jpg', 'reguler', 2, NULL, NULL, '2026-07-12 23:36:09', ''),
(3, 'Virahmanda Abelia Ismaya', 'Divisi Acara', 3, 'img/Virahmanda Abelia Ismaya.jpg', 'reguler', 3, NULL, NULL, '2026-07-12 23:36:09', ''),
(4, 'Muhammad Fiqri Mahendra', 'Divisi Acara', 3, 'img/Muhammad Fiqri Mahendra.jpg', 'pekerja', 4, NULL, NULL, '2026-07-12 23:36:09', 'KKN (kerje2 ngape gk)'),
(5, 'Sebastianus Aditia', 'Divisi Humas', 4, 'img/Sebastianus Aditia.jpg', 'reguler', 5, NULL, NULL, '2026-07-12 23:36:09', 'Tetap semangat dan jangan menyerah walaupun kesulitan menantangmu'),
(6, 'Khairunisa Salsabila', 'Divisi Humas', 4, 'img/Khairunisa Salsabila.jpg', 'pekerja', 6, NULL, NULL, '2026-07-12 23:36:09', ''),
(7, 'Tiara Fitriani', 'Divisi PDD', 5, 'img/Tiara Fitriani.jpg', 'reguler', 7, NULL, NULL, '2026-07-12 23:36:09', ''),
(8, 'Siti Aliyah', 'Divisi PDD', 5, 'img/Siti Aliyah.jpg', 'pekerja', 8, NULL, NULL, '2026-07-12 23:36:09', ''),
(9, 'Fathurrahman', 'Divisi Perlengkapan', 6, 'img/Fathurrahman.jpg', 'reguler', 9, NULL, NULL, '2026-07-12 23:36:09', ''),
(10, 'Halimah Tusa\'Diah', 'Divisi Perlengkapan', 6, 'img/Halimah Tusa\'Diah.jpg', 'pekerja', 10, NULL, NULL, '2026-07-12 23:36:09', ''),
(11, 'Ibu Kania Khairunnisa, M.Psi., Psikolog', 'Dosen Pembimbing Lapangan (DPL)', NULL, 'img/default-avatar.png', 'reguler', 0, NULL, NULL, '2026-07-21 16:12:11', '');

-- --------------------------------------------------------

--
-- Table structure for table `app_settings`
--

CREATE TABLE `app_settings` (
  `key_name` varchar(100) NOT NULL,
  `key_val` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `app_settings`
--

INSERT INTO `app_settings` (`key_name`, `key_val`) VALUES
('lokasi_prokja_seeded', '1');

-- --------------------------------------------------------

--
-- Table structure for table `bidang_prokja`
--

CREATE TABLE `bidang_prokja` (
  `id` int(11) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `icon_emoji` varchar(10) DEFAULT NULL,
  `warna_badge` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bidang_prokja`
--

INSERT INTO `bidang_prokja` (`id`, `kode`, `nama`, `icon_emoji`, `warna_badge`) VALUES
(1, 'pendidikan', 'Pendidikan', '', 'primary'),
(2, 'kesehatan', 'Kesehatan', '', 'danger'),
(3, 'ekonomi', 'Ekonomi', '', 'success'),
(4, 'lingkungan', 'Lingkungan', '', 'warning'),
(5, 'survei-lokasi', 'Survei Lokasi', NULL, NULL),
(6, 'berkunjung-kekantor-lurah', 'Berkunjung Kekantor Lurah', NULL, NULL),
(7, 'perkenalan-kelompok-kkn', 'Perkenalan Kelompok kkn', NULL, NULL),
(8, 'vidioperkenalankelompokkkn12', 'Vidio Perkenalan Kelompok Kkn 12', NULL, NULL),
(9, 'pelepasan-mahasiswa-kkn-2026', 'Pelepasan Mahasiswa Kkn 2026', NULL, NULL),
(10, 'penyerahan-mahasiswa-kkn-oleh-', 'Penyerahan  Mahasiswa Kkn Oleh Dosen Pendamping Kepada Kepala Kelurahan  Pal lima', NULL, NULL),
(11, 'pendampinganterpaduumkmberbasi', 'Pendampingan Terpadu UMKM Berbasis Potensi Lokal', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `divisi_panitia`
--

CREATE TABLE `divisi_panitia` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `divisi_panitia`
--

INSERT INTO `divisi_panitia` (`id`, `nama`) VALUES
(3, 'Divisi Acara'),
(4, 'Divisi Humas'),
(5, 'Divisi PDD'),
(6, 'Divisi Perlengkapan'),
(1, 'Ketua'),
(2, 'Sekretaris');

-- --------------------------------------------------------

--
-- Table structure for table `galeri_beranda`
--

CREATE TABLE `galeri_beranda` (
  `id` int(11) NOT NULL,
  `path_foto` varchar(255) NOT NULL,
  `kategori` enum('warga','anak','lokasi') NOT NULL,
  `keterangan` varchar(150) DEFAULT NULL,
  `ukuran_tile` enum('sm','md','lg') DEFAULT 'sm',
  `urutan` int(11) DEFAULT 0,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `galeri_beranda`
--

INSERT INTO `galeri_beranda` (`id`, `path_foto`, `kategori`, `keterangan`, `ukuran_tile`, `urutan`, `dibuat_pada`) VALUES
(1, 'img/20171130105645.jpg', 'lokasi', 'Lokasi & Desa', 'lg', 1, '2026-07-12 23:36:13'),
(2, 'img/20171130105645.jpg', 'warga', 'Kegiatan Warga', 'md', 2, '2026-07-12 23:36:13'),
(3, 'img/20171130105645.jpg', 'anak', 'Kegiatan Anak', 'sm', 3, '2026-07-12 23:36:13'),
(4, 'img/20171130105645.jpg', 'anak', 'Kegiatan Anak', 'sm', 4, '2026-07-12 23:36:13'),
(5, 'img/20171130105645.jpg', 'anak', 'Kegiatan Anak', 'lg', 5, '2026-07-12 23:36:13'),
(6, 'img/20171130105645.jpg', 'anak', 'Kegiatan Anak', 'sm', 6, '2026-07-12 23:36:13'),
(7, 'img/20171130105645.jpg', 'anak', 'Kegiatan Anak', 'sm', 7, '2026-07-12 23:36:13'),
(8, 'img/20171130105645.jpg', 'anak', 'Kegiatan Anak', 'md', 8, '2026-07-12 23:36:13');

-- --------------------------------------------------------

--
-- Table structure for table `informasi_posko`
--

CREATE TABLE `informasi_posko` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(150) NOT NULL,
  `kategori` varchar(100) DEFAULT 'Perlengkapan Posko',
  `penanggung_jawab` varchar(255) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `informasi_posko`
--

INSERT INTO `informasi_posko` (`id`, `nama_barang`, `kategori`, `penanggung_jawab`, `keterangan`, `dibuat_pada`) VALUES
(1, 'Kompor', 'Perlengkapan Memasak', 'Diah', 'Peralatan masak posko', '2026-07-21 16:03:34'),
(2, 'Gas 3 kg', 'Perlengkapan Memasak', 'Diah', 'Kebutuhan konsumsi posko', '2026-07-21 16:03:34'),
(3, 'Dandang', 'Perlengkapan Memasak', 'Diah', 'Memasak nasi / mengukus', '2026-07-21 16:03:34'),
(4, 'Kuali', 'Perlengkapan Dapur', 'Fatur', 'Peralatan penggorengan', '2026-07-21 16:03:34'),
(5, 'Gelas & Piring', 'Peralatan Makan', 'Masing-masing', 'Milik pribadi anggota', '2026-07-21 16:03:34'),
(6, 'Galon Air', 'Konsumsi Air Minum', 'Nisa, Abel, Fikri', 'Menjaga pasokan air minum', '2026-07-21 16:03:34'),
(7, 'Pisau', 'Peralatan Dapur', 'Nisa, Adit', 'Peralatan potong bahan makanan', '2026-07-21 16:03:34'),
(8, 'Talenan', 'Peralatan Dapur', 'Aley', 'Alas potong dapur', '2026-07-21 16:03:34'),
(9, 'Sudip', 'Perlengkapan Memasak', 'Aley', 'Alat pengaduk masakan', '2026-07-21 16:03:34'),
(10, 'Baskom', 'Wadah & Cucian', 'Tiara', 'Wadah cuci / penampung', '2026-07-21 16:03:34'),
(11, 'Tempat Lauk', 'Peralatan Makan', 'Mangkok Masing-masing', 'Wadah lauk posko', '2026-07-21 16:03:34'),
(12, 'Nyedot Air Galon', 'Tugas Operasional', 'Abel', 'Penyedotan air galon posko', '2026-07-21 16:03:34');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_acara`
--

CREATE TABLE `jadwal_acara` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `hari` varchar(20) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `agenda` varchar(255) NOT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `jadwal_acara`
--

INSERT INTO `jadwal_acara` (`id`, `tanggal`, `hari`, `waktu`, `agenda`, `pic`, `keterangan`) VALUES
(12, '2026-08-06', 'Kamis', '08.00-selesai', 'Pengataran Surat', NULL, 'Pengantaran Surat ke sd 13 dan sma 11 Pontianak'),
(13, '2026-08-06', 'Kamis', '00.00', 'Pendataan Umkm', NULL, 'jam disesuaikan'),
(14, '2026-08-06', 'Kamis', '00.00', 'Menujungi tpa', NULL, 'jam disesuaikan'),
(15, '2026-08-07', 'Jumat', '08.00-selesai', 'sosialisai proker  prodi', NULL, 'di sdn 13 pontianak'),
(16, '2026-08-07', 'Jumat', '15.00-selesai', 'Proker Mengunjungi Umkm Keripik (Manajemen)', NULL, NULL),
(17, '2026-08-08', 'Sabtu', '08.00-selesai', 'Pendataan Umkm', NULL, NULL),
(18, '2026-08-09', 'Minggu', '08.00-selesai', 'belajar senam', NULL, 'di posko');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_piket`
--

CREATE TABLE `jadwal_piket` (
  `id` int(11) NOT NULL,
  `hari` varchar(20) NOT NULL,
  `shift` varchar(50) DEFAULT 'Pagi - Sore',
  `tugas` varchar(255) DEFAULT 'Piket Posko & Kebersihan',
  `petugas` text NOT NULL,
  `keterangan` text DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `jadwal_piket`
--

INSERT INTO `jadwal_piket` (`id`, `hari`, `shift`, `tugas`, `petugas`, `keterangan`, `dibuat_pada`) VALUES
(1, 'Senin', '08:00 - 17:00', 'Piket Posko & Penerima Tamu', 'Rizki Tri Saputra, Anggi Rahmawati, Virahmanda Abelia Ismaya', 'Menjaga posko utama dan mengarsip surat masuk', '2026-07-21 15:51:50'),
(2, 'Selasa', '08:00 - 17:00', 'Piket Kebersihan & Konsumsi', 'Muhammad Fiqri Mahendra, Siti Aliyah, Fathurrahman', 'Menyiapkan logistik posko dan konsumsi harian', '2026-07-21 15:51:50'),
(3, 'Rabu', '08:00 - 17:00', 'Piket Humas & Publikasi', 'Sebastianus Aditia, Khairunisa Salsabila, Halimah Tusa\'Diah', 'Mendokumentasikan & koordinasi warga lokal', '2026-07-21 15:51:50'),
(4, 'Kamis', '08:00 - 17:00', 'Piket PDD & Dokumentasi', 'Tiara Fitriani, Siti Aliyah, Fathurrahman', 'Mengelola arsip media dan sosial media KKN', '2026-07-21 15:51:50'),
(5, 'Jumat', '08:00 - 17:00', 'Piket Perlengkapan Posko', 'Sebastianus Aditia, Khairunisa Salsabila, Halimah Tusa\'Diah', 'Memeriksa inventaris barang dan peralatan KKN', '2026-07-21 15:51:50'),
(6, 'Sabtu', '08:00 - 15:00', 'Piket Posko & Evaluasi', 'Rizki Tri Saputra, Anggi Rahmawati, Tiara Fitriani', 'Piket sabtu dan persiapan rekap kegiatan', '2026-07-21 15:51:50'),
(7, 'Minggu', 'Penuh', 'Piket Bersama / Kerja Bakti', 'Seluruh Anggota KKN Kelompok 12', 'Pembersihan posko mingguan bersama-sama', '2026-07-21 15:51:50');

-- --------------------------------------------------------

--
-- Table structure for table `kegiatan`
--

CREATE TABLE `kegiatan` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `hari` varchar(15) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `bidang_id` int(11) DEFAULT NULL,
  `jam_mulai` varchar(100) DEFAULT NULL,
  `jam_selesai` varchar(100) DEFAULT NULL,
  `lokasi` varchar(150) DEFAULT NULL,
  `sasaran` varchar(150) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `hasil` text DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kegiatan`
--

INSERT INTO `kegiatan` (`id`, `tanggal`, `hari`, `judul`, `bidang_id`, `jam_mulai`, `jam_selesai`, `lokasi`, `sasaran`, `deskripsi`, `hasil`, `dibuat_pada`) VALUES
(1, '2026-07-13', 'Senin', 'Ketemu Kepala Keluharan', 6, '11:57', '13.01', 'Jl. Husein Hamzah No.2, Pal Lima, Kec. Pontianak Bar., Kota Pontianak, Kalimantan Barat 78113', 'kepala kelurahan', 'Kunjungan dan audiensi dengan Kepala Kelurahan Pal Lima untuk memperkenalkan program kerja KKN, melakukan survei awal, serta membangun koordinasi sebagai persiapan pelaksanaan kegiatan.', 'Diperolehnya izin dan dukungan dari Kepala Kelurahan serta informasi awal mengenai kondisi dan potensi wilayah KKN.', '2026-07-15 16:59:21'),
(4, '2026-07-20', 'Senin', 'Kegiatan Pelepasan Mahasiswa Kkn 2026', 9, '12.30', '14.44', 'Jl. Jenderal Ahmad Yani No.111, Bangka Belitung Laut, Kec. Pontianak Tenggara, Kota Pontianak, Kalimantan Barat 78123', 'Seluruh Mahasiswa KKn 2026', 'Pada hari Senin, 20 Juli 2026, peserta KKN Universitas Muhammadiyah Pontianak mengikuti kegiatan pelepasan di Auditorium Universitas Muhammadiyah Pontianak sebagai tanda dimulainya pelaksanaan KKN Tahun 2026. Kegiatan ini berisi pembekalan dan arahan bagi mahasiswa sebelum diterjunkan ke lokasi KKN.', 'Peserta mengikuti kegiatan pelepasan KKN, memperoleh pembekalan mengenai pelaksanaan dan etika KKN, memahami tugas serta tanggung jawab, dan dinyatakan siap melaksanakan KKN sesuai arahan LP3M Universitas Muhammadiyah Pontianak.', '2026-07-22 09:43:19'),
(5, '2026-07-27', 'Senin', 'Pelepasan Dosen Pembimbing Lapangan Kepada Kelurahan  Pal Lima', 10, '9.30', '11.00', 'Jl. Husein Hamzah No.2, Pal Lima, Kec. Pontianak Bar., Kota Pontianak, Kalimantan Barat 78113', 'Kepala Kelurahan Pal lima', 'Pelepasan dan penyerahan resmi mahasiswa KKN oleh Dosen Pembimbing Lapangan (DPL) kepada pihak Kelurahan Pal Lima sebagai awal pelaksanaan program KKN. Kegiatan meliputi perkenalan, penyampaian tujuan dan program kerja KKN, serta koordinasi awal dengan pihak kelurahan guna mendukung kelancaran pelaksanaan kegiatan selama masa KKN.', 'Mahasiswa KKN resmi diterima oleh Kelurahan Pal Lima, koordinasi awal terlaksana, program kerja tersampaikan, serta komitmen kerja sama berhasil terjalin.', '2026-07-27 11:37:57'),
(6, '2026-08-02', 'Minggu', 'Kegiatan Gotong Royong Dengan Warga Didis Permai 8', 4, '07.30', '09.00', 'Jl. Husein Hamzah Komp. Didis Permai No.8 no 16c, Sungai Beliung, Kec. Pontianak Bar., Kota Pontianak, Kalimantan Barat 78114', 'Seluruh Warga Dan Mahasiswa Kkn Kelompok 12', 'Pelaksanaan kegiatan gotong royong bersama warga Komplek Didis Permai 8 dalam rangka membersihkan lingkungan, merapikan fasilitas umum, dan meningkatkan kesadaran masyarakat akan pentingnya menjaga kebersihan serta mempererat kebersamaan antara warga dan mahasiswa KKN.', 'Lingkungan menjadi lebih bersih dan rapi, saluran air terbebas dari sampah, serta terjalinnya kerja sama dan silaturahmi yang baik antara warga dengan Mahasiswa KKN Kelompok 12.', '2026-08-04 01:24:39'),
(7, '2026-08-04', 'Selasa', 'Kunjungan dan Observasi UMKM Pembuatan Tape', 3, '10.00', '12.00', 'Jl. Nipah Kuning Dalam, Gang Manggala', 'Pelaku usaha Umkm', 'Melaksanakan kunjungan dan observasi ke UMKM Lidya Tape yang berlokasi di Jalan Nipah, Gang Manggala, Kelurahan Benua Melayu Darat, Kecamatan Pontianak Selatan, Kota Pontianak, Kalimantan Barat. Kegiatan ini bertujuan untuk mengenal profil usaha, mengamati proses pembuatan tape, serta memperoleh informasi mengenai proses produksi, pengemasan, dan pemasaran produk. Selain itu, dilakukan diskusi dengan pemilik UMKM terkait tantangan yang dihadapi serta peluang pengembangan usaha guna mendukung peningkatan daya saing UMKM.', 'Diperoleh informasi mengenai profil usaha, proses pembuatan tape, teknik pengemasan, dan strategi pemasaran yang diterapkan oleh UMKM Lidya Tape. Hasil observasi ini menjadi bahan identifikasi potensi dan permasalahan UMKM sebagai dasar penyusunan program kerja KKN yang mendukung pengembangan usaha.', '2026-08-04 07:06:12'),
(8, '2026-08-07', 'Jumat', 'Kunjungan Ke sdn 13 Pontianak Barat', 1, '07.00', '09.00', 'Jl. Husein Hamzah, Pal Lima, Kec. Pontianak Bar., Kota Pontianak, Kalimantan Barat 78114', 'Siswa Sd Kelas 6,5,1', 'Sosialiasi Perlindungan Anak\r\n Sosialiasi Psikoedukasi Pencegahan Bullying\r\n Edukasi Cuci Tanggan Pakai Sabun (Ctps)', 'Siswa memahami perlindungan anak, pencegahan bullying, dan pentingnya CTPS.', '2026-08-08 12:12:34'),
(9, '2026-08-08', 'Sabtu', 'Kegiatan Mengajar di Tpq  Masjid Al-ikhsan', 1, '07.10', '10.00', 'Jl. Komp. Villa ArthalandPal Lima, Kec. Pontianak Bar., Kota Pontianak, Kalimantan Barat 78114', 'Seluruh Siswa Tpq  Masjid Al-ikhsan', 'Membimbing siswa dalam membaca Al-Qur\'an dan belajar dasar-dasar keagamaan.', 'Siswa mengikuti pembelajaran dengan baik dan memahami materi yang diberikan.', '2026-08-08 13:22:05'),
(10, '2026-08-06', 'Kamis', 'Melakukan Survey dan Pendataan Umkm Hidroponik Seledri', 3, '13.30', '15.00', 'Jln.Berdikari Gg Chandra Berdikari', 'Pemilik Usaha', 'Kegiatan kunjungan dan survei dilakukan untuk mengenal kondisi serta potensi usaha pelaku UMKM secara langsung. Kegiatan meliputi observasi usaha, wawancara dengan pelaku usaha, serta identifikasi kebutuhan dan kendala dalam pengembangan UMKM.', 'Tersedianya data awal mengenai UMKM sebagai dasar penyusunan program pendampingan, pengembangan usaha, dan peningkatan potensi UMKM.', '2026-08-12 02:59:08'),
(12, '2026-08-10', 'Senin', 'Kegiatan Survey Umkm dan Kunjungan di Pangkalan Batu Alam dan Pasir', 3, '13.30', '15.00', 'Jl.Husien Hamzah Pal 5', 'Pelaku/Pemilik Usaha Umkm', 'Melakukan survey lapangan dan pendataan terhadap pelaku usaha UMKM batu alam dan pasir di wilayah Jl. Husien Hamzah Pal 5. Kegiatan meliputi wawancara langsung dengan pemilik usaha terkait profil usaha, jenis produk, skala produksi, serta kendala yang dihadapi dalam menjalankan usaha.', 'Diperoleh data profil UMKM batu alam dan pasir (jumlah usaha, jenis produk, kapasitas produksi) yang akan digunakan sebagai bahan pemetaan potensi ekonomi desa/kelurahan.', '2026-08-12 03:10:58'),
(13, '2026-08-09', 'Minggu', 'Senam Bersama dan Sosialisai Stunting', 2, '07.30', '10.00', 'Jl. Husein Hamzah (Pal 5), Komplek Villa Artha Land, Kel. Pal Lima, Kec. Pontianak Barat, Kota Pontianak, Kalimantan Barat 78244', 'Kader Posyandu Dan Seluruh Masyarakat yang hadir', 'Melaksanakan kegiatan senam bersama dan sosialisasi stunting kepada kader posyandu dan masyarakat sekitar. Kegiatan diawali dengan senam pagi bersama, dilanjutkan dengan penyampaian materi sosialisasi mengenai pengertian, penyebab, dampak, serta cara pencegahan stunting pada anak.', 'Meningkatnya pemahaman kader posyandu dan masyarakat mengenai pentingnya pencegahan stunting sejak dini, serta terjalinnya kedekatan antara mahasiswa KKN dengan warga melalui kegiatan senam bersama.', '2026-08-12 03:20:58'),
(14, '2026-08-10', 'Senin', 'Penimbangan dan Pegukuran Berat Badan di Posyandu Artha Land', 2, '09.10', '11.00', 'Jl. Komp. Villa ArthalandPal Lima, Kec. Pontianak Bar., Kota Pontianak, Kalimantan Barat 78114', 'Selurah Anak Balita Posyandu Artha Land', 'Melaksanakan kegiatan penimbangan dan pengukuran berat badan balita di Posyandu Artha Land bersama kader posyandu setempat. Kegiatan meliputi pencatatan data berat badan dan tinggi/panjang badan balita pada Kartu Menuju Sehat (KMS) sebagai upaya pemantauan tumbuh kembang anak dan deteksi dini stunting.', 'Terkumpulnya data berat dan tinggi badan seluruh balita peserta Posyandu Artha Land yang tercatat pada KMS, sebagai bahan pemantauan status gizi dan tumbuh kembang anak secara berkala.', '2026-08-12 03:55:35');

-- --------------------------------------------------------

--
-- Table structure for table `kegiatan_foto`
--

CREATE TABLE `kegiatan_foto` (
  `id` int(11) NOT NULL,
  `kegiatan_id` int(11) NOT NULL,
  `path_foto` varchar(255) NOT NULL,
  `keterangan` varchar(150) DEFAULT NULL,
  `diunggah_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kegiatan_foto`
--

INSERT INTO `kegiatan_foto` (`id`, `kegiatan_id`, `path_foto`, `keterangan`, `diunggah_pada`) VALUES
(1, 1, 'uploads/kegiatan/kegiatan-1-1784125992-8739bddf.jpeg', NULL, '2026-07-15 21:33:12'),
(3, 4, 'uploads/kegiatan/kegiatan-4-1784688225-95c8c04c.jpeg', NULL, '2026-07-22 09:43:46'),
(80, 9, 'uploads/kegiatan/kegiatan-9-1786515752-55805833.jpeg', NULL, '2026-08-12 06:22:32'),
(81, 9, 'uploads/kegiatan/kegiatan-9-1786515752-43c099eb.jpeg', NULL, '2026-08-12 06:22:32'),
(82, 9, 'uploads/kegiatan/kegiatan-9-1786515752-7400fda9.jpeg', NULL, '2026-08-12 06:22:32'),
(83, 9, 'uploads/kegiatan/kegiatan-9-1786515752-bd626a4b.jpeg', NULL, '2026-08-12 06:22:32'),
(84, 9, 'uploads/kegiatan/kegiatan-9-1786515752-9705b40b.jpeg', NULL, '2026-08-12 06:22:32'),
(85, 9, 'uploads/kegiatan/kegiatan-9-1786515752-70b171cb.jpeg', NULL, '2026-08-12 06:22:32'),
(86, 8, 'uploads/kegiatan/kegiatan-8-1786515792-a177d72c.jpeg', NULL, '2026-08-12 06:23:12'),
(87, 8, 'uploads/kegiatan/kegiatan-8-1786515792-4efad2a3.jpeg', NULL, '2026-08-12 06:23:12'),
(88, 8, 'uploads/kegiatan/kegiatan-8-1786515792-a168fdd2.jpeg', NULL, '2026-08-12 06:23:12'),
(89, 8, 'uploads/kegiatan/kegiatan-8-1786515792-2f144641.jpeg', NULL, '2026-08-12 06:23:12'),
(90, 8, 'uploads/kegiatan/kegiatan-8-1786515792-f319ee14.jpeg', NULL, '2026-08-12 06:23:12'),
(91, 8, 'uploads/kegiatan/kegiatan-8-1786515792-3addf35e.jpeg', NULL, '2026-08-12 06:23:12'),
(92, 8, 'uploads/kegiatan/kegiatan-8-1786515792-8868d8b8.jpeg', NULL, '2026-08-12 06:23:12'),
(93, 8, 'uploads/kegiatan/kegiatan-8-1786515792-e54c158e.jpeg', NULL, '2026-08-12 06:23:12'),
(94, 8, 'uploads/kegiatan/kegiatan-8-1786515792-d7c80cd0.jpeg', NULL, '2026-08-12 06:23:12'),
(95, 8, 'uploads/kegiatan/kegiatan-8-1786515792-721530af.jpeg', NULL, '2026-08-12 06:23:12'),
(96, 8, 'uploads/kegiatan/kegiatan-8-1786515792-88da85e7.jpeg', NULL, '2026-08-12 06:23:12'),
(97, 8, 'uploads/kegiatan/kegiatan-8-1786515792-748226ea.jpeg', NULL, '2026-08-12 06:23:12'),
(98, 14, 'uploads/kegiatan/kegiatan-14-1786515847-823f7dd5.jpeg', NULL, '2026-08-12 06:24:07'),
(99, 14, 'uploads/kegiatan/kegiatan-14-1786515847-76219897.jpeg', NULL, '2026-08-12 06:24:07'),
(100, 14, 'uploads/kegiatan/kegiatan-14-1786515847-81a2bf79.jpeg', NULL, '2026-08-12 06:24:07'),
(101, 13, 'uploads/kegiatan/kegiatan-13-1786515913-524054b1.jpeg', NULL, '2026-08-12 06:25:13'),
(102, 13, 'uploads/kegiatan/kegiatan-13-1786515913-41f490eb.jpeg', NULL, '2026-08-12 06:25:13'),
(103, 13, 'uploads/kegiatan/kegiatan-13-1786515913-db15e3de.jpeg', NULL, '2026-08-12 06:25:13'),
(104, 13, 'uploads/kegiatan/kegiatan-13-1786515913-a8123883.jpeg', NULL, '2026-08-12 06:25:13'),
(105, 13, 'uploads/kegiatan/kegiatan-13-1786515913-f67d1e6a.jpeg', NULL, '2026-08-12 06:25:13'),
(106, 13, 'uploads/kegiatan/kegiatan-13-1786515913-04be63aa.jpeg', NULL, '2026-08-12 06:25:13'),
(107, 13, 'uploads/kegiatan/kegiatan-13-1786515913-f4dbf70a.jpeg', NULL, '2026-08-12 06:25:13'),
(108, 13, 'uploads/kegiatan/kegiatan-13-1786515913-bae8aadc.jpeg', NULL, '2026-08-12 06:25:13'),
(109, 13, 'uploads/kegiatan/kegiatan-13-1786515913-f67613fe.jpeg', NULL, '2026-08-12 06:25:13'),
(110, 13, 'uploads/kegiatan/kegiatan-13-1786515913-b1efb7ad.jpeg', NULL, '2026-08-12 06:25:13'),
(111, 13, 'uploads/kegiatan/kegiatan-13-1786515913-c590a44a.jpeg', NULL, '2026-08-12 06:25:13'),
(112, 13, 'uploads/kegiatan/kegiatan-13-1786515913-5f369bc8.jpeg', NULL, '2026-08-12 06:25:13'),
(113, 13, 'uploads/kegiatan/kegiatan-13-1786515913-f5b40799.jpeg', NULL, '2026-08-12 06:25:13'),
(114, 12, 'uploads/kegiatan/kegiatan-12-1786515946-931f5aa6.jpeg', NULL, '2026-08-12 06:25:46'),
(115, 10, 'uploads/kegiatan/kegiatan-10-1786515960-9fa042e1.jpeg', NULL, '2026-08-12 06:26:00'),
(116, 7, 'uploads/kegiatan/kegiatan-7-1786515978-c6d9543f.jpeg', NULL, '2026-08-12 06:26:18'),
(117, 5, 'uploads/kegiatan/kegiatan-5-1786516135-8ab1c6fc.jpeg', NULL, '2026-08-12 06:28:54');

-- --------------------------------------------------------

--
-- Table structure for table `kegiatan_rundown`
--

CREATE TABLE `kegiatan_rundown` (
  `id` int(11) NOT NULL,
  `kegiatan_id` int(11) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `agenda` varchar(255) NOT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kontak_humas`
--

CREATE TABLE `kontak_humas` (
  `id` int(11) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `jabatan` varchar(150) NOT NULL,
  `no_hp` varchar(50) NOT NULL,
  `wilayah` varchar(150) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kontak_humas`
--

INSERT INTO `kontak_humas` (`id`, `nama`, `jabatan`, `no_hp`, `wilayah`, `keterangan`, `dibuat_pada`) VALUES
(1, 'Bapak Kepala Kelurahan', 'Kepala Kelurahan Pal Lima', '081234567890', 'Pal Lima', 'Lurah Pal Lima, Pontianak Barat', '2026-07-26 16:05:46'),
(2, 'Bhabinkamtibmas Pal Lima', 'Bhabinkamtibmas (Polsek)', '081298765432', 'Pal Lima', 'Kontak Kamtibmas Kepolisian', '2026-07-26 16:05:46'),
(3, 'Babinsa Pal Lima', 'Babinsa (Koramil)', '081345678901', 'Pal Lima', 'Kontak Pertahanan/TNI Koramil', '2026-07-26 16:05:46'),
(4, 'Kepala Puskesmas Pal Lima', 'Kepala Puskesmas / Nakes', '081567890123', 'Pal Lima', 'Kontak Layanan Kesehatan Posko', '2026-07-26 16:05:46'),
(5, 'Ketua RW 01', 'Ketua RW / Tokoh Masyarakat', '081678901234', 'RW 01 Pal Lima', 'Ketua RW Sub-Wilayah Posko', '2026-07-26 16:05:46'),
(6, 'Ketua Karang Taruna', 'Ketua Pemuda / Karang Taruna', '081789012345', 'Pal Lima', 'Koordinator Pemuda Setempat', '2026-07-26 16:05:46'),
(7, 'Ibu Kania Khairunnisa, M.Psi.', 'Dosen Pembimbing Lapangan (DPL)', '081890123456', 'UMP', 'DPL Kelompok 12 UMP', '2026-07-26 16:05:46');

-- --------------------------------------------------------

--
-- Table structure for table `login_log`
--

CREATE TABLE `login_log` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `berhasil` tinyint(1) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `waktu` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `login_log`
--

INSERT INTO `login_log` (`id`, `username`, `berhasil`, `ip_address`, `waktu`) VALUES
(57, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 16:47:15'),
(58, 'rizkitrisaputra', 0, '127.0.0.1', '2026-07-21 16:50:50'),
(59, 'rizkitrisaputra', 1, '127.0.0.1', '2026-07-21 16:51:05'),
(60, 'rizkitrisaputra', 1, '127.0.0.1', '2026-07-21 16:51:11'),
(61, 'rizkitrisaputra', 1, '172.18.0.1', '2026-07-21 16:51:55'),
(62, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 16:54:14'),
(63, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 17:34:38'),
(64, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 18:36:23'),
(65, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 18:56:25'),
(66, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:01:36'),
(67, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:05:03'),
(68, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:05:21'),
(69, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:08:58'),
(70, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:12:56'),
(71, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:16:50'),
(72, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:27:38'),
(73, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:31:33'),
(74, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:34:53'),
(75, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 19:57:26'),
(76, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 20:00:11'),
(77, 'anggierahmawati', 1, '172.18.0.1', '2026-07-21 20:00:34'),
(78, 'virahmanda', 1, '172.18.0.1', '2026-07-21 20:01:07'),
(79, 'tiarafitriani', 1, '172.18.0.1', '2026-07-21 20:11:14'),
(80, 'sitialiyah', 1, '172.18.0.1', '2026-07-21 20:11:54'),
(81, 'rizkitrisaputra', 1, '172.18.0.1', '2026-07-21 20:12:22'),
(82, 'virahmandaabeliaismaya', 1, '172.18.0.1', '2026-07-21 20:12:55'),
(83, 'anggirahmawati', 1, '172.18.0.1', '2026-07-21 20:13:30'),
(84, 'halimahtusadiah', 1, '172.18.0.1', '2026-07-21 20:13:48'),
(85, 'fathurrahman', 1, '172.18.0.1', '2026-07-21 20:14:50'),
(86, 'dwiseptiani', 0, '172.18.0.1', '2026-07-21 20:15:11'),
(87, 'kaniakhairunnisa', 0, '172.18.0.1', '2026-07-21 20:15:29'),
(88, 'kaniakhairunnisa', 0, '172.18.0.1', '2026-07-21 20:15:42'),
(89, 'kaniakhairunnisa', 0, '172.18.0.1', '2026-07-21 20:15:42'),
(90, 'kania', 1, '172.18.0.1', '2026-07-21 20:17:28'),
(91, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 20:21:01'),
(92, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-21 20:33:38'),
(93, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 00:07:00'),
(94, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 00:21:57'),
(95, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 00:29:05'),
(96, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 00:29:59'),
(97, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 00:30:18'),
(98, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 00:31:55'),
(99, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 00:58:00'),
(100, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 00:59:49'),
(101, 'muhammadfiqrimahendra', 1, '::1', '2026-07-22 01:44:54'),
(102, 'muhammadfiqrimahendra', 1, '::1', '2026-07-22 01:49:32'),
(103, 'muhammadfiqrimahendra', 1, '::1', '2026-07-22 01:49:52'),
(104, 'diah', 1, '::1', '2026-07-22 01:54:07'),
(105, 'muhammadfiqrimahendra', 1, '::1', '2026-07-22 01:56:20'),
(106, 'muhammadfiqrimahendra', 1, '::1', '2026-07-22 01:57:21'),
(107, 'muhammadfiqrimahendra', 1, '::1', '2026-07-22 01:57:48'),
(108, 'kania', 1, '::1', '2026-07-22 01:58:43'),
(109, 'kania', 1, '::1', '2026-07-22 02:01:56'),
(110, 'muhammadfiqrimahendra', 1, '172.18.0.1', '2026-07-22 09:17:49'),
(111, 'kania', 1, '172.18.0.1', '2026-07-22 10:06:52'),
(112, 'kania', 1, '172.18.0.1', '2026-07-22 10:07:28'),
(113, 'kania', 1, '182.11.129.28', '2026-07-22 03:51:43'),
(114, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-22 03:52:36'),
(115, 'tiarafitriani', 1, '182.11.153.234', '2026-07-22 04:03:19'),
(116, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-22 05:37:03'),
(117, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-22 05:42:01'),
(118, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-22 05:53:44'),
(119, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-22 05:58:45'),
(120, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-22 07:26:35'),
(121, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-22 07:44:09'),
(122, 'adit', 1, '182.2.105.199', '2026-07-22 09:33:06'),
(123, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-22 09:37:40'),
(124, 'muhammadfiqrimahendra', 1, '182.11.129.28', '2026-07-26 13:47:34'),
(125, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-26 14:52:00'),
(126, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-26 14:57:33'),
(127, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-26 15:08:21'),
(128, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-26 15:13:29'),
(129, 'rizkitrisaputra', 1, '182.11.152.70', '2026-07-26 15:56:58'),
(130, 'sebastianusaditia', 1, '182.11.152.70', '2026-07-26 15:57:49'),
(131, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-27 11:27:57'),
(132, 'sebastianusaditia', 1, '182.11.152.70', '2026-07-27 12:13:38'),
(133, 'sebastianusaditia', 1, '182.11.152.70', '2026-07-27 13:59:23'),
(134, 'sebastianusaditia', 1, '182.11.152.70', '2026-07-27 16:03:31'),
(135, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-27 16:05:24'),
(136, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-27 16:09:41'),
(137, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-27 16:35:32'),
(138, 'kania', 1, '182.11.152.70', '2026-07-27 16:49:43'),
(139, 'kania', 1, '182.11.152.70', '2026-07-27 17:03:37'),
(140, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-27 17:04:24'),
(141, 'muhammadfiqrimahendra', 1, '182.11.152.70', '2026-07-27 17:18:49'),
(142, 'sebastianusaditia', 1, '182.11.152.70', '2026-07-27 17:28:49'),
(143, 'muhammadfiqrimahendra', 1, '182.11.130.139', '2026-07-29 13:33:04'),
(144, 'muhammadfiqrimahendra', 1, '114.10.137.248', '2026-08-03 12:43:32'),
(145, 'muhammadfiqrimahendra', 1, '114.10.137.248', '2026-08-03 13:09:58'),
(146, 'muhammadfiqrimahendra', 1, '114.10.137.194', '2026-08-04 01:21:39'),
(147, 'muhammadfiqrimahendra', 1, '114.10.137.210', '2026-08-04 06:44:32'),
(148, 'muhammadfiqrimahendra', 1, '114.10.137.232', '2026-08-04 07:43:45'),
(149, 'muhammadfiqrimahendra', 1, '182.2.100.40', '2026-08-04 10:49:09'),
(150, 'muhammadfiqrimahendra', 1, '128.14.66.169', '2026-08-05 00:54:40'),
(151, 'muhammadfiqrimahendra', 1, '114.10.137.223', '2026-08-05 07:42:35'),
(152, 'muhammadfiqrimahendra', 1, '114.10.137.253', '2026-08-05 15:00:53'),
(153, 'muhammadfiqrimahendra', 1, '114.10.137.197', '2026-08-08 03:59:56'),
(154, 'muhammadfiqrimahendra', 1, '114.10.137.229', '2026-08-08 11:56:32'),
(155, 'muhammadfiqrimahendra', 1, '114.10.137.229', '2026-08-08 13:08:05'),
(156, 'muhammadfiqrimahendra', 1, '114.10.137.229', '2026-08-08 16:12:44'),
(157, 'muhammadfiqrimahendra', 1, '114.10.137.229', '2026-08-08 23:00:20'),
(158, 'muhammadfiqrimahendra', 1, '114.10.137.195', '2026-08-11 11:57:46'),
(159, 'muhammadfiqrimahendra', 1, '114.10.137.221', '2026-08-12 02:19:54'),
(160, 'muhammadfiqrimahendra', 1, '182.2.101.28', '2026-08-12 03:35:35'),
(161, 'muhammadfiqrimahendra', 1, '182.2.101.28', '2026-08-12 05:42:37'),
(162, 'muhammadfiqrimahendra', 1, '182.2.101.28', '2026-08-12 05:57:45'),
(163, 'muhammadfiqrimahendra', 1, '182.2.101.28', '2026-08-12 06:09:48'),
(164, 'muhammadfiqrimahendra', 1, '114.10.137.221', '2026-08-12 06:21:05'),
(165, 'muhammadfiqrimahendra', 1, '114.10.137.221', '2026-08-12 06:27:59'),
(166, 'muhammadfiqrimahendra', 1, '114.10.137.221', '2026-08-12 06:30:42'),
(167, 'muhammadfiqrimahendra', 1, '182.2.101.28', '2026-08-12 07:13:57');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi_prokja`
--

CREATE TABLE `lokasi_prokja` (
  `id` int(11) NOT NULL,
  `program_kerja_id` int(11) DEFAULT NULL,
  `nama_lokasi` varchar(255) NOT NULL,
  `kategori_lokasi` varchar(100) DEFAULT 'Program Kerja',
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `pengunggah_nama` varchar(150) DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lokasi_prokja`
--

INSERT INTO `lokasi_prokja` (`id`, `program_kerja_id`, `nama_lokasi`, `kategori_lokasi`, `latitude`, `longitude`, `keterangan`, `pengunggah_nama`, `dibuat_pada`) VALUES
(5, NULL, 'Kantor Kelurahan Pal Lima (Pusat Layanan)', 'Posko KKN / Sekretariat', '-0.03693700', '109.28857200', 'Pusat Koordinasi dan Layanan Administrasi KKN Kelompok 12', 'Kelompok 12', '2026-08-04 07:08:28'),
(11, NULL, 'SD NEGERI 13 KECAMATAN PONTIANAK BARAT', 'Sekolah & Pendidikan', '-0.03770000', '109.28770000', 'Sosialiasi Perlindungan Anak\r\nSosialiasi Psikoedukasi Pencegahan Bullying\r\nEdukasi Cuci Tanggan Pakai Sabun (Ctps)', 'Muhammad Fiqri Mahendra', '2026-08-04 07:25:48'),
(15, 8, 'UMKM LIDYA TAPE', 'UMKM & Ekonomi Kreatif', '-0.02080000', '109.28301240', 'Melakukan Survei Lokasi Umkm dan Melihat Proses Pembuatan tap', 'Muhammad Fiqri Mahendra', '2026-08-04 09:46:43'),
(16, NULL, 'Tpq Al-ihsan', 'Sekolah & Pendidikan', '-0.02709160', '109.28768810', 'Pelaksanaan kegitan belajar mengaji dan mewarnai', 'Muhammad Fiqri Mahendra', '2026-08-08 16:21:18'),
(17, NULL, 'Posko Kkn Kelompok 12 Ump', 'Posko KKN', '-0.02937250', '109.28683630', 'Lokasi Posko dan Kantor Kkn kelompok 12 ump', 'Muhammad Fiqri Mahendra', '2026-08-11 12:09:17'),
(30, NULL, 'Posyandu Artha Land', 'Posyandu & Kesehatan', '-0.02708900', '109.28760000', 'Senam Bersama Kader Posyandu Artha Land dan Sosialisasi Stunting\r\npenimbangan dan pengukuran badan anak usia dini', 'Muhammad Fiqri Mahendra', '2026-08-11 16:05:07');

-- --------------------------------------------------------

--
-- Table structure for table `materi_presentasi`
--

CREATE TABLE `materi_presentasi` (
  `id` int(11) NOT NULL,
  `program_kerja_id` int(11) DEFAULT NULL,
  `judul_materi` varchar(255) NOT NULL,
  `tujuan_program` text DEFAULT NULL,
  `sasaran_program` text DEFAULT NULL,
  `dampak_program` text DEFAULT NULL,
  `nama_kelompok` varchar(150) NOT NULL,
  `pemateri_nama` varchar(150) NOT NULL,
  `pemateri_foto` varchar(255) NOT NULL,
  `path_file` varchar(255) NOT NULL,
  `tipe_file` varchar(50) DEFAULT NULL,
  `ukuran_file` int(11) DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `materi_presentasi`
--

INSERT INTO `materi_presentasi` (`id`, `program_kerja_id`, `judul_materi`, `tujuan_program`, `sasaran_program`, `dampak_program`, `nama_kelompok`, `pemateri_nama`, `pemateri_foto`, `path_file`, `tipe_file`, `ukuran_file`, `dibuat_pada`) VALUES
(37, NULL, 'Edukasi Perlindungan Anak', 'Menciptakan lingkungan yang aman serta membekali anak dengan pengetahuan dasar untuk melindungi diri sendiri.', 'Siswa Sekolah Dasar kelas V', 'Meningkatnya pengetahuan dan kesadaran siswa tentang perlindungan diri sehingga mampu mengenali bahaya, menjaga diri, dan berani melapor kepada orang dewasa yang dipercaya.', 'Divisi Acara', 'Rizki Tri Saputra', 'img/rizki tri saputra.jpg', 'uploads/materi/materi-1785829875-6c09a5ee.pptx', 'pptx', 462812, '2026-08-04 07:51:15'),
(38, NULL, 'Dampak Serangan Cyber', 'Memberikan Pemahaman tentang serangan Cyber', 'Siswa Kelas 11 Sma 11 pontianak', 'Memberikan Pencengaha terhadap serangan cyber', 'Divisi Acara', 'Muhammad Fiqri Mahendra', 'img/Muhammad Fiqri Mahendra.jpg', 'uploads/materi/materi-1785830372-12930bd2.pptx', 'pptx', 1414616, '2026-08-04 07:59:32'),
(39, NULL, 'Psikoedukasi Pencegahan Bullying', 'Meningkatkan pemahaman peserta mengenai pengertian, bentuk, penyebab, dan dampak bullying serta membekali peserta dengan pengetahuan dan keterampilan dasar untuk mencegah, mengenali, dan melindungi diri dari tindakan perundungan.', 'Siswa Kelas VI SDN 13 Pontianak dan Siswa Kelas XI SMA Negeri 11 Pontianak.', 'Meningkatnya kesadaran peserta tentang bahaya bullying.\r\nPeserta mampu mengenali berbagai bentuk bullying.\r\nTerciptanya lingkungan sekolah yang lebih aman, nyaman, dan saling menghargai.\r\nBerkurangnya perilaku bullying di lingkungan sekolah.', 'Divisi Acara', 'Sebastianus Aditia', 'img/Sebastianus Aditia.jpg', 'uploads/materi/materi-1785834787-d504c2cc.pptx', 'pptx', 41802, '2026-08-04 09:13:07'),
(40, NULL, 'Sosialisai Cuci Tanggan Pakai Sabun', 'Memberikan edukasi kepada peserta mengenai pentingnya mencuci tangan pakai sabun dengan langkah yang benar sebagai upaya menjaga kebersihan diri dan mencegah penyebaran penyakit.', 'Anak-anak dan siswa di lingkungan Kelurahan Pal Lima, khususnya peserta kegiatan sosialisasi.', 'Meningkatnya pengetahuan dan kesadaran peserta mengenai pentingnya menjaga kebersihan tangan serta terbentuknya kebiasaan mencuci tangan pakai sabun dalam kehidupan sehari-hari.', 'Divisi Acara', 'Khairunisa Salsabila', 'img/Khairunisa Salsabila.jpg', 'uploads/materi/materi-1786206933-d404e531.pdf', 'pdf', 2245513, '2026-08-08 16:35:33');

-- --------------------------------------------------------

--
-- Table structure for table `notulensi_rapat`
--

CREATE TABLE `notulensi_rapat` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `judul_rapat` varchar(255) NOT NULL,
  `pembahasan` text NOT NULL,
  `keputusan` text DEFAULT NULL,
  `peserta` varchar(255) DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profil_desa`
--

CREATE TABLE `profil_desa` (
  `id` int(11) NOT NULL,
  `nama_desa` varchar(100) NOT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `jumlah_penduduk` varchar(50) DEFAULT NULL,
  `potensi` varchar(150) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `profil_desa`
--

INSERT INTO `profil_desa` (`id`, `nama_desa`, `kecamatan`, `kabupaten`, `jumlah_penduduk`, `potensi`, `deskripsi`, `foto`) VALUES
(1, 'Pal Lima', 'Pontianak Barat', 'Pontianak', ' 3.200 Jiwa', 'Pertanian & UMKM', 'Kelurahan Pal Lima merupakan bagian dari Kecamatan Pontianak Barat, Kota Pontianak, yang terus berkembang melalui pelayanan masyarakat, pembangunan, serta pemberdayaan warga menuju lingkungan yang maju dan sejahtera.', 'img/desa.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `program_kerja`
--

CREATE TABLE `program_kerja` (
  `id` int(11) NOT NULL,
  `bidang_id` int(11) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `periode` varchar(50) DEFAULT 'Juli  Agustus 2026',
  `deskripsi` text DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `urutan` int(11) NOT NULL DEFAULT 0,
  `status` enum('draft','terbit') NOT NULL DEFAULT 'draft',
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `program_kerja_foto`
--

CREATE TABLE `program_kerja_foto` (
  `id` int(11) NOT NULL,
  `program_kerja_id` int(11) NOT NULL,
  `path_foto` varchar(255) NOT NULL,
  `judul` varchar(150) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `is_cover` tinyint(1) DEFAULT 0,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `surat_kkn`
--

CREATE TABLE `surat_kkn` (
  `id` int(11) NOT NULL,
  `nomor_surat` varchar(100) NOT NULL,
  `tanggal_surat` varchar(100) NOT NULL,
  `lampiran` varchar(100) DEFAULT '-',
  `hal` varchar(255) NOT NULL,
  `kepada` text NOT NULL,
  `pembuka` text DEFAULT NULL,
  `isi_poin` text NOT NULL,
  `penutup` text DEFAULT NULL,
  `jabatan_kiri` varchar(150) DEFAULT 'Kepala Kelurahan Pal Lima',
  `nama_kiri` varchar(150) DEFAULT '.....................................',
  `nidn_kiri` varchar(100) DEFAULT 'NIP. .....................................',
  `jabatan_kanan` varchar(150) DEFAULT 'Ketua KKN Kelompok 12',
  `nama_kanan` varchar(150) DEFAULT 'Rizki Tri Saputra',
  `nim_kanan` varchar(100) DEFAULT 'NIM. .....................................',
  `dibuat_pada` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `surat_kkn`
--

INSERT INTO `surat_kkn` (`id`, `nomor_surat`, `tanggal_surat`, `lampiran`, `hal`, `kepada`, `pembuka`, `isi_poin`, `penutup`, `jabatan_kiri`, `nama_kiri`, `nidn_kiri`, `jabatan_kanan`, `nama_kanan`, `nim_kanan`, `dibuat_pada`) VALUES
(9, '012/KKN-12/UMP/VII/2026', 'Pontianak, 3 Agustus 2026', 'Lampiran: 1 (satu) lembar', 'Permohonan Izin Pelaksanaan Program Kerja', 'Kepada Yth. \r\nKepala Sekolah SD Negeri 13 Pontianak\r\ndi -\r\n  Tempat', 'Assalamu’alaikum warahmatullahi wabarakatuh.\r\n\r\nDengan hormat,\r\n\r\nSehubungan dengan pelaksanaan program Kuliah Kerja Nyata (KKN) Tahun 2026 Universitas Muhammadiyah Pontianak, kami selaku Panitia KKN bermaksud memohon izin kepada pihak SMP Negeri 14 Pontianak untuk melaksanakan salah satu program kerja mahasiswa KKN berupa kegiatan sosialisasi dengan tema-tema sebagai berikut:\r\n\r\nSosialisasi Kesehatan Mental pada Remaja;\r\nSosialisasi Kesehatan Fisik pada Remaja;\r\nSosialisasi Pencegahan Perundungan (Bullying); dan\r\nSosialisasi Bahaya Penyalahgunaan NAPZA.\r\n\r\nDemikian permohonan ini kami sampaikan. Besar harapan kami agar pihak SMP Negeri 14 Pontianak berkenan memberikan izin dan dukungan terhadap pelaksanaan kegiatan tersebut. Adapun kegiatan ini direncanakan akan dilaksanakan pada:', '', 'Demikian surat ini kami sampaikan, untuk menjadi pedoman dan dilaksanakan dengan penuh tanggung jawab.', 'Kepala Kelurahan Pal Lima', '.....................................', 'NIP. .....................................', 'Ketua KKN Kelompok 12', 'Rizki Tri Saputra', 'NIM. .....................................', '2026-08-03 06:17:43'),
(10, '012/KKN-12/UMP/VII/2026', 'Pontianak, 26 Juli 2026', '-', 'Pelaksanaan Kegiatan KKN Kelompok 12', 'Yth. 1. Bapak Kepala Kelurahan Pal Lima\r\n2. Ketua RW/RT Kelurahan Pal Lima\r\n3. Tokoh Masyarakat Sub-Kelurahan\r\ndi -\r\nPontianak', 'Memperhatikan pelaksanaan kegiatan Kuliah Kerja Nyata (KKN) Kelompok 12 Universitas Muhammadiyah Pontianak di wilayah Kelurahan Pal Lima, Pontianak Barat, perlu kami sampaikan hal-hal sebagai berikut:', '1. Masa pelaksanaan kegiatan Kuliah Kerja Nyata (KKN) Kelompok 12 berlangsung mulai tanggal 20 Juli sampai dengan 30 Agustus 2026;\r\n2. Seluruh mahasiswa KKN Kelompok 12 wajib melaksanakan program kerja yang telah disetujui oleh Dosen Pembimbing Lapangan dan pihak Kelurahan;\r\n3. Dalam pelaksanaan program kerja, seluruh anggota hendaknya senantiasa berkoordinasi dengan pengurus RT, RW, dan tokoh masyarakat setempat;\r\n4. Seluruh warga masyarakat diimbau untuk turut serta berpartisipasi aktif dan mendukung kelancaran program kegiatan KKN Kelompok 12.', 'Demikian surat ini kami sampaikan, untuk menjadi pedoman dan dilaksanakan dengan penuh tanggung jawab.', 'Kepala Kelurahan Pal Lima', '.....................................', 'NIP. .....................................', 'Ketua KKN Kelompok 12', 'Rizki Tri Saputra', 'NIM. .....................................', '2026-08-03 06:23:53'),
(11, '012/KKN-12/UMP/VII/2026', 'Pontianak, 26 Juli 2026', '-', 'Pelaksanaan Kegiatan KKN Kelompok 12', 'Yth. 1. Bapak Kepala Kelurahan Pal Lima\r\n2. Ketua RW/RT Kelurahan Pal Lima\r\n3. Tokoh Masyarakat Sub-Kelurahan\r\ndi -\r\nPontianak', 'Memperhatikan pelaksanaan kegiatan Kuliah Kerja Nyata (KKN) Kelompok 12 Universitas Muhammadiyah Pontianak di wilayah Kelurahan Pal Lima, Pontianak Barat, perlu kami sampaikan hal-hal sebagai berikut:', '1. Masa pelaksanaan kegiatan Kuliah Kerja Nyata (KKN) Kelompok 12 berlangsung mulai tanggal 20 Juli sampai dengan 30 Agustus 2026;\r\n2. Seluruh mahasiswa KKN Kelompok 12 wajib melaksanakan program kerja yang telah disetujui oleh Dosen Pembimbing Lapangan dan pihak Kelurahan;\r\n3. Dalam pelaksanaan program kerja, seluruh anggota hendaknya senantiasa berkoordinasi dengan pengurus RT, RW, dan tokoh masyarakat setempat;\r\n4. Seluruh warga masyarakat diimbau untuk turut serta berpartisipasi aktif dan mendukung kelancaran program kegiatan KKN Kelompok 12.', 'Demikian surat ini kami sampaikan, untuk menjadi pedoman dan dilaksanakan dengan penuh tanggung jawab.', 'Sekretaris Panitia', 'Rachmat Wahid Saleh Insani, S.Kom., M.Cs', 'NIDN. 1120079001', 'Ketua Panitia', 'Sukardi, S.E., M.M', 'NIDN. 1122028201', '2026-08-03 06:34:07'),
(12, '012/KKN-12/UMP/VII/2026', 'Pontianak, 11 Agustus 2026', '1 (satu) lembar', 'Pelaksanaan Program Kerja dan Promosi Kampus', 'Kepada Yth.\r\nBapak/Ibu Kepala Sekolah\r\nSMA Negeri 11 Pontianak\r\ndi Tempat', 'Sehubungan dengan pelaksanaan Kuliah Kerja Nyata (KKN) Tahun 2026 Universitas Muhammadiyah Pontianak, kami selaku mahasiswa Kelompok KKN 12 bermaksud memohon izin kepada Bapak/Ibu Kepala Sekolah SMA Negeri 11 Pontianak untuk melaksanakan salah satu program kerja berupa kegiatan \r\n\r\nHari/Tanggal : Selasa, 11 Agustus 2026 dan Rabu, 12 Agustus 2026\r\nWaktu : Menyesuaikan dengan jadwal kegiatan belajar mengajar di sekolah\r\nTempat : SMA Negeri 11 Pontianak\r\n\r\nMelalui surat ini, kami berharap Bapak/Ibu Kepala Sekolah berkenan memberikan izin serta dukungan terhadap pelaksanaan kegiatan tersebut. Besar harapan kami agar kegiatan ini dapat terlaksana dengan baik, berjalan lancar, serta memberikan manfaat bagi peserta didik maupun pihak sekolah sebagai bagian dari kontribusi mahasiswa dalam pelaksanaan Tri Dharma Perguruan Tinggi.\r\n\r\nDemikian surat permohonan ini kami sampaikan. Atas perhatian, izin, dan kerja sama yang diberikan, kami mengucapkan terima kasih', '', '', 'Kepala Kelurahan Pal Lima', '.....................................', 'NIP. .....................................', 'Ketua KKN Kelompok 12', 'Rizki Tri Saputra', 'NIM. .....................................', '2026-08-04 03:57:08');

-- --------------------------------------------------------

--
-- Table structure for table `surat_masuk`
--

CREATE TABLE `surat_masuk` (
  `id` int(11) NOT NULL,
  `nomor_surat` varchar(100) NOT NULL,
  `pengirim` varchar(255) NOT NULL,
  `perihal` varchar(255) NOT NULL,
  `tanggal_terima` date NOT NULL,
  `keterangan` text DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `video_kegiatan`
--

CREATE TABLE `video_kegiatan` (
  `id` int(11) NOT NULL,
  `program_kerja_id` int(11) DEFAULT NULL,
  `judul_video` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `pengunggah_nama` varchar(150) NOT NULL,
  `pengunggah_foto` varchar(255) NOT NULL,
  `path_video` varchar(255) NOT NULL,
  `tipe_video` varchar(50) DEFAULT NULL,
  `ukuran_file` int(11) DEFAULT NULL,
  `dibuat_pada` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `video_kegiatan`
--

INSERT INTO `video_kegiatan` (`id`, `program_kerja_id`, `judul_video`, `deskripsi`, `pengunggah_nama`, `pengunggah_foto`, `path_video`, `tipe_video`, `ukuran_file`, `dibuat_pada`) VALUES
(2, NULL, 'Kelompok KKN 12, Izin Tampil!', 'Perkenalkan, kami adalah Kelompok KKN 12 Universitas Muhammadiyah Pontianak yang akan melaksanakan pengabdian kepada masyarakat di Kelurahan Pal Lima. Video ini merupakan perkenalan seluruh anggota tim yang siap berkolaborasi, belajar, dan memberikan kontribusi terbaik melalui berbagai program kerja selama pelaksanaan Kuliah Kerja Nyata (KKN). Semoga kehadiran kami dapat memberikan manfaat serta menjalin hubungan yang baik dengan masyarakat. Mari bersama menciptakan perubahan yang positif! 💙✨', 'Muhammad Fiqri Mahendra', 'img/Muhammad Fiqri Mahendra.jpg', 'https://www.youtube.com/embed/FAMFrdoiBXY', 'youtube', NULL, '2026-07-22 09:26:30'),
(3, NULL, 'Pelepasan dan Penyerahan Mahasiswa KKN Kelompok 12 kepada Kelurahan Pal Lima', 'Video ini mendokumentasikan kegiatan pelepasan Dosen Pembimbing Lapangan (DPL) dan penyerahan resmi mahasiswa KKN Kelompok 12 Universitas Muhammadiyah Pontianak kepada Kelurahan Pal Lima. Kegiatan ini meliputi perkenalan, penyampaian tujuan dan program kerja KKN, serta koordinasi awal bersama pihak kelurahan sebagai bentuk komitmen dalam menjalankan pengabdian kepada masyarakat.', 'Muhammad Fiqri Mahendra', 'img/Muhammad Fiqri Mahendra.jpg', 'https://youtube.com/shorts/70zgcRLL5_I?feature=share', 'youtube', NULL, '2026-07-27 11:45:10'),
(4, NULL, 'Gotong Royong Bersama Warga Didis Permai 8', 'Kebersihan lingkungan dimulai dari kebersamaan. 💚 Mahasiswa KKN Kelompok 12 bersama warga Komplek Didis Permai 8 melaksanakan kegiatan gotong royong membersihkan lingkungan. Terima kasih kepada seluruh warga yang telah berpartisipasi. Semoga semangat kebersamaan ini terus terjaga. dan bersih-bersih posko', 'Muhammad Fiqri Mahendra', 'img/Muhammad Fiqri Mahendra.jpg', 'uploads/video_kegiatan/video_1785812300_6a71554c7cdb3.mp4', 'local', NULL, '2026-08-04 02:55:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unik_absen` (`kegiatan_id`,`anggota_id`),
  ADD KEY `anggota_id` (`anggota_id`);

--
-- Indexes for table `akun_anggota`
--
ALTER TABLE `akun_anggota`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `anggota_id` (`anggota_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id`),
  ADD KEY `divisi_panitia_id` (`divisi_panitia_id`);

--
-- Indexes for table `app_settings`
--
ALTER TABLE `app_settings`
  ADD PRIMARY KEY (`key_name`);

--
-- Indexes for table `bidang_prokja`
--
ALTER TABLE `bidang_prokja`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- Indexes for table `divisi_panitia`
--
ALTER TABLE `divisi_panitia`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama` (`nama`);

--
-- Indexes for table `galeri_beranda`
--
ALTER TABLE `galeri_beranda`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `informasi_posko`
--
ALTER TABLE `informasi_posko`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jadwal_acara`
--
ALTER TABLE `jadwal_acara`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jadwal_piket`
--
ALTER TABLE `jadwal_piket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bidang_id` (`bidang_id`);

--
-- Indexes for table `kegiatan_foto`
--
ALTER TABLE `kegiatan_foto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kegiatan_id` (`kegiatan_id`);

--
-- Indexes for table `kegiatan_rundown`
--
ALTER TABLE `kegiatan_rundown`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kegiatan_id` (`kegiatan_id`);

--
-- Indexes for table `kontak_humas`
--
ALTER TABLE `kontak_humas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_log`
--
ALTER TABLE `login_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lokasi_prokja`
--
ALTER TABLE `lokasi_prokja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `materi_presentasi`
--
ALTER TABLE `materi_presentasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notulensi_rapat`
--
ALTER TABLE `notulensi_rapat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profil_desa`
--
ALTER TABLE `profil_desa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `program_kerja`
--
ALTER TABLE `program_kerja`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bidang_id` (`bidang_id`);

--
-- Indexes for table `program_kerja_foto`
--
ALTER TABLE `program_kerja_foto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `program_kerja_id` (`program_kerja_id`);

--
-- Indexes for table `surat_kkn`
--
ALTER TABLE `surat_kkn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surat_masuk`
--
ALTER TABLE `surat_masuk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video_kegiatan`
--
ALTER TABLE `video_kegiatan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `akun_anggota`
--
ALTER TABLE `akun_anggota`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `anggota`
--
ALTER TABLE `anggota`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `bidang_prokja`
--
ALTER TABLE `bidang_prokja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `divisi_panitia`
--
ALTER TABLE `divisi_panitia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `galeri_beranda`
--
ALTER TABLE `galeri_beranda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `informasi_posko`
--
ALTER TABLE `informasi_posko`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `jadwal_acara`
--
ALTER TABLE `jadwal_acara`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `jadwal_piket`
--
ALTER TABLE `jadwal_piket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kegiatan`
--
ALTER TABLE `kegiatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `kegiatan_foto`
--
ALTER TABLE `kegiatan_foto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `kegiatan_rundown`
--
ALTER TABLE `kegiatan_rundown`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kontak_humas`
--
ALTER TABLE `kontak_humas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `login_log`
--
ALTER TABLE `login_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT for table `lokasi_prokja`
--
ALTER TABLE `lokasi_prokja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `materi_presentasi`
--
ALTER TABLE `materi_presentasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `notulensi_rapat`
--
ALTER TABLE `notulensi_rapat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profil_desa`
--
ALTER TABLE `profil_desa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `program_kerja`
--
ALTER TABLE `program_kerja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `program_kerja_foto`
--
ALTER TABLE `program_kerja_foto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `surat_kkn`
--
ALTER TABLE `surat_kkn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `surat_masuk`
--
ALTER TABLE `surat_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `video_kegiatan`
--
ALTER TABLE `video_kegiatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `absensi`
--
ALTER TABLE `absensi`
  ADD CONSTRAINT `absensi_ibfk_1` FOREIGN KEY (`kegiatan_id`) REFERENCES `kegiatan` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `absensi_ibfk_2` FOREIGN KEY (`anggota_id`) REFERENCES `anggota` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `akun_anggota`
--
ALTER TABLE `akun_anggota`
  ADD CONSTRAINT `akun_anggota_ibfk_1` FOREIGN KEY (`anggota_id`) REFERENCES `anggota` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `anggota`
--
ALTER TABLE `anggota`
  ADD CONSTRAINT `anggota_ibfk_1` FOREIGN KEY (`divisi_panitia_id`) REFERENCES `divisi_panitia` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD CONSTRAINT `kegiatan_ibfk_1` FOREIGN KEY (`bidang_id`) REFERENCES `bidang_prokja` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `kegiatan_foto`
--
ALTER TABLE `kegiatan_foto`
  ADD CONSTRAINT `kegiatan_foto_ibfk_1` FOREIGN KEY (`kegiatan_id`) REFERENCES `kegiatan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `kegiatan_rundown`
--
ALTER TABLE `kegiatan_rundown`
  ADD CONSTRAINT `kegiatan_rundown_ibfk_1` FOREIGN KEY (`kegiatan_id`) REFERENCES `kegiatan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `program_kerja`
--
ALTER TABLE `program_kerja`
  ADD CONSTRAINT `program_kerja_ibfk_1` FOREIGN KEY (`bidang_id`) REFERENCES `bidang_prokja` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `program_kerja_foto`
--
ALTER TABLE `program_kerja_foto`
  ADD CONSTRAINT `program_kerja_foto_ibfk_1` FOREIGN KEY (`program_kerja_id`) REFERENCES `program_kerja` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
